using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSPFacebookLogIn : FsmStateAction {

		public string scopes = "email,publish_actions";


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			if(SPFacebook.instance.IsLoggedIn) {
				OnSuccses();
				return;
			}

			SPFacebook.instance.Init();

			SPFacebook.instance.addEventListener(FacebookEvents.AUTHENTICATION_FAILED,  			OnFail);
			SPFacebook.instance.addEventListener(FacebookEvents.AUTHENTICATION_SUCCEEDED,   		OnSuccses);

			SPFacebook.instance.Login(scopes);


		}

		private void RemoveListners() {
			SPFacebook.instance.removeEventListener(FacebookEvents.POST_FAILED,  			OnFail);
			SPFacebook.instance.removeEventListener(FacebookEvents.POST_SUCCEEDED,   		OnSuccses);
		}

		private void OnFail() {
			Fsm.Event(failEvent);
			RemoveListners();
			Finish();
		}
		
		private void OnSuccses() {

			if(!SPFacebook.instance.IsLoggedIn) {
				OnFail();
				return;
			}

			Fsm.Event(successEvent);
			RemoveListners();
			Finish();
		}

	}
}


