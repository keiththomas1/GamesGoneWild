using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSPFacebookNativePostScreenShot : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;

		
		public override void OnEnter() {

			FacebookPostScreenshotTask post = 	FacebookPostScreenshotTask.Create();
			post.addEventListener(BaseEvent.COMPLETE, OnComplete);
			post.Post(message.Value);
			
			
		}
		
		private void OnComplete(CEvent e) {
			e.dispatcher.removeEventListener(BaseEvent.COMPLETE, OnComplete);
			Finish();
		}


		
	}
}



