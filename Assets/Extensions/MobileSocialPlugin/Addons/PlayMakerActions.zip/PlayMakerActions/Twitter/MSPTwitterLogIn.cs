using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSPTwitterLogIn : FsmStateAction {

		private static string TWITTER_CONSUMER_KEY = "TWITTER_CONSUMER_KEY";
		private static string TWITTER_CONSUMER_SECRET = "TWITTER_CONSUMER_SECRET";


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			if(SPTwitter.instance.IsAuthed) {
				OnSuccses();
				return;
			}

			SPTwitter.instance.Init(TWITTER_CONSUMER_KEY, TWITTER_CONSUMER_SECRET);

			SPTwitter.instance.addEventListener(TwitterEvents.AUTHENTICATION_SUCCEEDED,  OnSuccses);
			SPTwitter.instance.addEventListener(TwitterEvents.AUTHENTICATION_FAILED,  	OnFail);


			SPTwitter.instance.AuthenticateUser();


		}

		private void RemoveListners() {
			SPTwitter.instance.removeEventListener(TwitterEvents.AUTHENTICATION_SUCCEEDED,  OnSuccses);
			SPTwitter.instance.removeEventListener(TwitterEvents.AUTHENTICATION_FAILED,  	OnFail);
		}

		private void OnFail() {
			Fsm.Event(failEvent);
			RemoveListners();
			Finish();
		}
		
		private void OnSuccses() {

			if(!SPTwitter.instance.IsAuthed) {
				OnFail();
				return;
			}

			Fsm.Event(successEvent);
			RemoveListners();
			Finish();
		}

	}
}


